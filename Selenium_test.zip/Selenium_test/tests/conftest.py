import pytest

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

@pytest.fixture(scope="session")
def browser(): 
    """
    TMS-1: [web][catalog] Проверка SKU товара
    """
		# Описываем опции запуска браузера
    chrome_options = Options()
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("start-maximized") # открываем на полный экран
    chrome_options.add_argument("--disable-infobars") # отключаем инфо сообщения
    chrome_options.add_argument("--disable-extensions") # отключаем расширения
    chrome_options.add_argument("--disable-gpu") # Только для Windows
    chrome_options.add_argument("--disable-dev-shm-usage")
    # chrome_options.add_argument("--headless") # спец. режим "без браузера"
	
    service = Service()# устанавливаем webdriver в соответствии с версией используемого браузер запускаем браузер с указанными выше настройками
    driver = webdriver.Chrome(service=service, options=chrome_options) # определяем адрес страницы для теста и переходим на неё
    yield driver
    driver.quit()